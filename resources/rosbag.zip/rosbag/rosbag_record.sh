ros2 bag record topics /kentora/status/BatteryLevel /kentora/status/EcuMode /sensing/gnss/fix /vehicle/status/control_mode /vehicle/status/gear_status /vehicle/status/steering_status /vehicle/status/velocity_status

